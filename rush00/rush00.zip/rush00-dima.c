/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00-dima.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dmlasko <dmlasko@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/09 10:46:17 by abadun            #+#    #+#             */
/*   Updated: 2024/03/09 15:46:18 by dmlasko          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		rush(int x, int y);
void	ft_putchar(char c);

void	print_out_a_row(int x, char c_left, char c_mid, char c_right)
{
	int	x_counter;

	x_counter = 0;
	while (x_counter < x)
	{
		if (x_counter == 0)
			ft_putchar(c_left);
		else if (x_counter == x - 1)
			ft_putchar(c_right);
		else
			ft_putchar(c_mid);
		x_counter++;
	}
	ft_putchar('\n');
}

int	rush(int x, int y)
{
	int		y_counter;
	char	*top;
	char	*mid; 
	char	*end; 

	top = "/*\\";
	mid = "| |";
	end = "\\*/";
	print_out_a_row(x, top[0], top[1], top[2]);
	y_counter = 0;
	while (y_counter < y - 2)
	{
		print_out_a_row(x, mid[0], mid[1], mid[2]);
		y_counter++;
	}
	print_out_a_row(x, end[0], end[1], end[2]);
}
